function check_empty(){
    document.getElementById('clear').addEventListener('click',function(event){
        document.getElementById('ship_status').value = 0;
        document.getElementById('material_number').value = '-';
        document.getElementById('location_code').value = '-';
        document.getElementById('material_name').value = '-';
        document.getElementById('qty').value = 0;
        document.getElementById('ship_qty').value = 0;
        document.getElementById('ship_qty').readOnly = true;
        document.getElementById('serial_number').readOnly = false;
        document.getElementById('serial_number').autofocus = true;

        // const url = this.getAttribute('data-url') + 'index.php?module=wms-ship';
        // window.open(url, '_blank');

    })
}